/*in broswer F12 pentru test*/
console.log("Functioneaza scriptura!");
function f()
{
    setInterval(actualizeazaTimp,1000);
    getLocation();
    getBrowser();
}
function actualizeazaTimp()
{
    let e=document.getElementById("dataMea");
    e.innerHTML=new Date();
}
function getLocation()
{
    if (navigator.geolocation)
    {
        navigator.geolocation.getCurrentPosition(showPosition);
    }
    else
    {
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}
function showPosition(position)
{
    let x = document.getElementById("locatiaMea");
    x.innerHTML = "Latitude: " + position.coords.latitude +
    "<br>Longitude: " + position.coords.longitude;
}
function getBrowser()
{
    let b = document.getElementById("browserulMeu");
    b.innerHTML = "Sistemul de operare folosit este " + navigator.platform;
    b.innerHTML = "Versiunea browserului " + navigator.appVersion;
    b.innerHTML = "Browserul folosit " + navigator.userAgent;
}
/*function desen(e){
    e.offsetX
    e.offsetY
}*/
function schimbaContinut(resursa)
{
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function()
    {
        if (this.readyState == 4 && this.status == 200)
        {
            document.getElementById("continut").innerHTML = this.responseText;
            //let o = JSON.parse(this.responseText)
        }
    };
    xhttp.open("GET", resursa + ".html", true);
    xhttp.send();
}
