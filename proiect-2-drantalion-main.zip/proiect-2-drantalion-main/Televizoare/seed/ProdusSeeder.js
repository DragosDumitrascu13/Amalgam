var Produs = require('../models/produs');

var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/televizoare');

var produse = [
    new Produs
    ({
    imagePath: 'https://static.orangeromania.ro/webshop-images/ott_sam2400201/samsung_televizor_samsung_108_cm_ue43au8072uxxh_l64793_8.png',
    title: 'Samsung',
    description: 'Cumpara acum televizorul Samsung smartTV UHD',
    price: 2500
    }),
    new Produs
    ({
    imagePath: 'https://spng.pngfind.com/pngs/s/111-1114210_jvc-49-inch-uhd-led-tv-lt-49n790.png',
    title: 'JVC',
    description: 'Cumpara acum televizorul JVC smartTV UHD',
    price: 1650
    }),
    new Produs
    ({
    imagePath: 'https://w7.pngwing.com/pngs/128/296/png-transparent-32-philips-32pft4101-led-backlit-lcd-high-definition-television-1080p-smart-tv-markt-television-display-advertising-media.png',
    title: 'Philips',
    description: 'Cumpara acum televizorul Philips smartTV UHD',
    price: 2340
    }),
];

var done = 0;
for (var i = 0; i < produse.length; i++)
{
    produse[i].save(function(err, res)
    {
        done++;
        if (done === produse.length)
        {
            deconecteazate();
        }
    });
}

function deconecteazate()
{
    mongoose.disconnect();
}