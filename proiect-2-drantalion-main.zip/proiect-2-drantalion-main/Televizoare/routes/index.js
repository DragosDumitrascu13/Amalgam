var express = require('express');
const res = require('express/lib/response');
const async = require('hbs/lib/async');
var router = express.Router();
var Produs = require('../models/produs');
var csrf = require('csurf');
const req = require('express/lib/request');

var csrfProtection = csrf();
router.use(csrfProtection);

/* GET home page. */
/*
router.get('/', function(req, res, next){
  await Produs.find(function(err, docs) {
    var productChunks = [];
    var chunkSize = 3;
    for (var i = 0; i < docs.length; i += chunkSize)
    {
      productChunks.push(docs.slice(i, i+chunkSize));
    }
    res.render('shop/index', { title: 'Televizoare', produse: productChunks });
  });
});
*/

router.get("/",async(req,res,next)=>{
  const products = await Produs.find({}).lean();
  var productChunks = [];
  var chunkSize = 3;
  for (var i = 0; i < products.length; i += chunkSize)
  {
    productChunks.push(products.slice(i, i+chunkSize));
  }
  res.render('shop/index', {title: 'Televizoare', produse: productChunks});
});

//const confession = await confession.find({}).lean();
//res.render('index',{confession});
/*
var products = Produs.find({}).exec((err,products)=>{
  if(err){
    res.send("error")
  } else {
    console.log(products);
    res.render('index',{title: 'Televizoare', products:products});
  }
});
*/
router.get('/user/signup', function(req,res,next){
  res.render('user/signup', {csrfToken: req.csrfToken()});
});

router.post('/user/signup', function(req,res,next){
  res.redirect('/');
});
module.exports = router;
